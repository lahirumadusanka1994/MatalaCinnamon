<footer id="contact">
         <div class="footer">
            <div class="container">
               <div class="row">
                
                  
                  <div class="col-md-3 ">
                     <ul class="location_icon">
                        <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i></a> No 13/1,Mathalapitpya,<br> Walawela,Matale.</li>
                        <li><a href="#"><i class="fa fa-volume-control-phone" aria-hidden="true"></i></a> +94713347205<br>  +94766265285</li>
                        <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a>mlahiru113@gmail.com / sameerauk1988@gmail.com</li>
                     </ul>
                  </div>
                  
                  <div class="col-md-2 ">
                     <h3>Menus</h3>
                     <ul class="link">
                        <li><a href="index.html">Home</a></li>                             
                        <li><a href="about.html">About</a></li>                                                     
                        <li><a href="products.html">Products</a></li>                             
                        
                        <li><a href="contact.html">Contact</a></li>
                     </ul>
                  </div>
                  <div class="col-md-7">
                     <form class="">
                        <h3>Contact Us</h3>
                        <div class="row">
                            <div class="col-md-6">
                            <input class="form-control" placeholder="Full Name" type="text" name="Full Name">
                            </div>
                            <div class="col-md-6">
                            <input class="form-control" placeholder="Phone " type="text" name="Full Name">
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-6">
                            <input class="form-control" placeholder="Enter Your Email" type="text" name="Full Name">
                            </div>
                            <div class="col-md-6">
                            <input class="form-control" placeholder="Country" type="text" name="Full Name">
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-md-6">
                            <textarea  class="form-control" placeholder="Message" type="textarea" name="Full Name"></textarea>
                            </div>
                        </div>
                     
                        
                        <button class="sub_btn">send a message</button>
                       
                        
                     </form>
                  </div>
               </div>
            </div>
            <div class="copyright">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <p>Copyright 2022 Mathala Cinnamon (Sadali Ceylon Pvt Ltd)</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>