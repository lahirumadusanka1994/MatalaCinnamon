/*******************************************************************************
 *
 * apikey
 * Author: pupunzi
 * Creation date: 08/05/15
 * https://console.developers.google.com/
 ******************************************************************************/

//jQuery.mbYTPlayer.apiKey = "AIzaSyCAHzbOtNhiLEU4RWxIKmyfcxUDDO_tzW0";
